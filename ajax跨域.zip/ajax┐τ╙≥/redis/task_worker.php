<?php
include 'conf/config.php';
ini_set('default_socket_timeout', -1);

$redis = new Redis();
$redis->connect(HOST, PORT_MASTER);

while($user = $redis->blPop('list:password:email', 'list:reg:email', 0)) {
	var_dump($user);
	sleep(1);
}
