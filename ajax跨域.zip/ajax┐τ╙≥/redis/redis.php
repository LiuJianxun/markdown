<?php
include 'conf/config.php';

$redis = new Redis();
$redis->connect(HOST,PORT_MASTER);

$redis->set("address","beijing");
$email = $redis->get('email');

echo $email;
echo "\n";
echo $redis->get('address');
echo "\n";
print_r($redis->info());