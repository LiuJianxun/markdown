<?php
include 'conf/config.php';

$redis = new Redis();
$redis->connect(HOST, PORT_MASTER);

$redis->lPush('key1', 'M');
/*
echo $redis->lLen('key1');
echo "\n";
echo $redis->lIndex('key1', 2);
*/