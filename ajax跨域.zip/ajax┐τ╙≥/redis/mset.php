<?php
include 'conf/config.php';

$redis = new Redis();
$redis->connect(HOST, PORT_MASTER);

$s = utime();
$arr = array();
for($i=1;$i<=200;$i++){
    $arr['k_'.$i] = $i;  
}

for($m=1;$m<=500;$m++){
    $redis->mset($arr);    #��MSETһ�δ�����ֵ   
}

$e = utime();
$u = $e - $s;
echo "10w data using time is : ".substr($u,0,5)." seconds \r\n";

//��ȡ�ű�����ʱ��
function utime(){
   $rtime=explode(" ",microtime());
   $usec =(double)$rtime[0];
   $sec  =(double)$rtime[1];
   return $sec+$usec;
}