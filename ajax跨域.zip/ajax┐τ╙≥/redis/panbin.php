<?php
header('Content-Type: text/html; charset=utf-8');
$redis = new Redis();
$redis->connect('127.0.0.1',6379);
       
$ip = $_SERVER['REMOTE_ADDR'];   
$ic = $redis->INCR($ip);
if(1 == $ic){
 $redis->EXPIRE($ip,60);
 echo 'set expirre time'.PHP_EOL;
        
}
if(20 <= $ic){
 echo 'access time so fast！'.PHP_EOL;
}
echo 'TTL=',$redis->ttl('ie'),'+';
echo 'access times =',$ic;