<?php
define("HOST","127.0.0.1");
define("PORT_MASTER","6379");
define("PORT_SLAVES","6378");