<?php
header("Content-Type:text/html;charset=utf-8");

interface Hash{
	public function hash($key);	
}

class crc32Hash implements Hash{
	public function hash($key){
		return sprintf("%u",crc32($key));
	}
}

class Consistent{
	protected $hash_functions;
	protected $virtual_num = 5;
	public $server_nodes = [];
	
	public function __construct(Hash $hash_functions){
		$this->hash_functions = $hash_functions;
	}
	
	protected function getServerPosition($str){
		return $this->hash_functions->hash($str);
	}
	
	protected function sortServer(){
		ksort($this->server_nodes);
	}
	
	public function find($key){		
		echo $position = $this->hash_functions->hash($key);		
		$server = current($this->server_nodes);		
		foreach($this->server_nodes as $key => $value){			
			if($key>$position){
				$server = $value;
				break;
			}			
		}		
		echo "\n";
		var_dump($server);
		echo "\n";
	}
	
	public function add($serverIp,$serverPort){
		for($i=0;$i<$this->virtual_num;$i++){
			$this->server_nodes[$this->getServerPosition($serverIp.":".$serverPort.":".$i)] = [
			    "ip" => $serverIp,
				"port" => $serverPort
			];
		}
		
		$this->sortServer();
	}
	
	public function remove($ip,$port){
		for($i=0;$i<$this->virtual_num;$i++){
			unset($this->server_nodes[$this->getServerPosition($ip.":".$port.":".$i)]);
		}		
	}		
}

$s = new Consistent(new crc32Hash());

$s->add("192.168.1.1","11211");
$s->add("192.168.2.1","11211");
$s->add("192.168.3.1","11211");
$s->add("192.168.4.1","11211");
//$s->add("192.168.5.1","11211");
//$s->add("192.168.6.1","11211");
//$s->add("192.168.7.1","11212");
//$s->add("192.168.8.1","11211");
//$s->add("192.168.9.1","11211");

//$s->remove("192.168.1.1","11211");
//$s->remove("192.168.2.1","11211");

$s->find("page");

print_r($s->server_nodes);

