<?php
include 'conf/config.php';

$redis = new Redis();
$redis->connect(HOST, PORT_MASTER);

$s = utime();
$redis->multi(Redis::PIPELINE);
for($i=0;$i<1000;$i++){
    for($j=0;$j<100;$j++){ 
        $redis->set("myname".$i,'ljx'.$i);
	}
}
$ret = $redis->exec();

$e = utime();
$u = $e - $s;
echo "10w data using time is : ".substr($u,0,5)." seconds \r\n";

//��ȡ�ű�����ʱ��
function utime(){
   $rtime=explode(" ",microtime());
   $usec =(double)$rtime[0];
   $sec  =(double)$rtime[1];
   return $sec+$usec;
}