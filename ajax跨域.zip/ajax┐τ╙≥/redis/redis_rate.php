<?php
include 'conf/config.php';

$redis = new Redis();
$redis->connect(HOST, PORT_MASTER);

$ip = '192.168.66.18';
$ipKey = md5('IP_KEY:'.$ip);
$listLength = $redis->lLen($ipKey);
if($listLength<20){
    $redis->lPush($ipKey,time()); 
	echo "push1";
}else{
    $time = $redis->lIndex($ipKey,'-1');
	if((time()-$time)<60){
	    exit("Access 20 minute limit, please try again later!");
	}else{
	    $redis->lPush($ipKey,time()); 
        $redis->lTrim($ipKey,0,19);	
        echo "push2";		
	}
}


/*
$ip = '192.168.66.18';
$ip_key = 'IP_KEY:'.$ip;
$is_exist = $redis->exists($ip_key);
if($is_exist){
    $times = $redis->incr($ip_key);
	if($times>20){
	    die("limit 20 times access per ip");
	}
	echo "now you can access !!! ";
}else{
    $redis->multi(Redis::PIPELINE);  #��������
	$redis->incr($ip_key);
	$redis->expire($ip_key,60);
	$ret = $redis->exec();
	echo "create new ip_key ";
}*/
