<script type="text/javascript" src="../jquery-1.8.3.js"></script>
<script type="text/javascript">
document.domain = "test.com";
window.onload = function(){	
    //这里可由后端处理完数据，并将结果由回调函数返回
	//实现类似异步局部刷新
    var like_type = "<?=$_GET['type']?>";
	var reviewid = "<?=$_GET['reviewid']?>";

	parent.callback('49','108',like_type);
};
</script>