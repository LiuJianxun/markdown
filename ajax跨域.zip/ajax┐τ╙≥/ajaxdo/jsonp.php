<?php
define('DIR_ROOT', dirname(__FILE__));
require_once('config/db.php');

$id = isset($_GET['id'])?intval($_GET['id']):0;
$type = isset($_GET['type']) ? trim(htmlspecialchars($_GET['type'])) : '';

if(empty($id)){
	$result = json_encode(array('ErrorNo'=>0,'msg'=>'参数错误!'));
}else{
	//操作数据库:给赞/踩:数量+1
	$table = 'video_updown';
	$addtime = time();
	$sql = "update {$table} set {$type}={$type}+1 ,addtime='{$addtime}' where id = '{$id}'";
	$u = mysqli_query($conn,$sql);
    if($u){
		$return=array('ErrorNo'=>1,'msg'=>'点赞成功!','type'=>$type);  
		$result=json_encode($return);  
    }else{
		$result = json_encode(array('ErrorNo'=>0,'msg'=>'系统繁忙!'));
	}	
}
sleep(1);
//返回结果
AjaxReturnJson($result);

//动态执行回调函数 
function AjaxReturnJson($result){	 
	echo $_GET['callback']."($result)";die;  //类似于jsonpCallback("返回数据");
}
