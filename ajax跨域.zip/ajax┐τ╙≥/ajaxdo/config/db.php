<?php
if(!defined('DIR_ROOT')) exit('access denied');

$conn = mysqli_connect('localhost','root','','msg') or die('Filed to connect'.mysqli_connect_error());
mysqli_query($conn,"set names utf8");

function select_all($conn,$sql){ 
    $res = mysqli_query($conn,$sql) or die("Failed".mysqli_error());
	$result = array();
	if(!empty($res)){
		while($row=mysqli_fetch_assoc($res)){	
			$result[] = $row;
		}	
	}
	mysqli_free_result($res);
	return $result;
} 

function select_one($conn,$sql){ 
    $res = mysqli_query($conn,$sql) or die("Failed".mysqli_error());
	$result = array();
	if(!empty($res)){
	   $result = mysqli_fetch_assoc($res);
	}
	mysqli_free_result($res);	
	return $result;
}