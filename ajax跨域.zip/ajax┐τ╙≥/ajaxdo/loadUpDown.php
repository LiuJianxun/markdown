<?php
define('DIR_ROOT', dirname(__FILE__));
require_once('config/db.php');

//接收数据
$newsId = isset($_GET['newsId']) ? trim(intval($_GET['newsId'])) : '';
$type = isset($_GET['type']) ? trim(htmlspecialchars($_GET['type'])) : '';
$addStep = isset($_GET['addStep']) ? trim(intval($_GET['addStep'])) : '';

if(empty($newsId)||empty($type)||empty($addStep)){
    AjaxReturnJson('-1','参数请求数据不全!');
}

if(isset($_COOKIE['up_down_video'])){
	AjaxReturnJson('-1','您已经操作过了!');
}

$table = 'video_updown';
$addtime = time();
$sql = "update {$table} set {$type}={$type}+1 ,addtime='{$addtime}' where id = '{$newsId}'";
$r = mysqli_query($conn,$sql);
if($r){//操作成功
    $zero_time = strtotime(date('Ymd')+1); //设置cookie过期时间零点
	$setCookie = md5($newsId).'_'.$type;
    setcookie('up_down_video',$setCookie,$zero_time,'/','.test.com');
	AjaxReturnJson('1','成功!',$type);
}else{
	AjaxReturnJson('-1','系统繁忙!');
}

function AjaxReturnJson($res,$msg,$action=''){
	echo $_GET['callback']."(".json_encode(array('res'=>$res,'msg'=>$msg,'action'=>$action)).");";die;	
}