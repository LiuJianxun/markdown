<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script type="text/javascript" src="../../jquery-1.8.3.js"></script>
<title>隐藏iframe实现局部刷新</title>
</head>
<body>
<iframe src="http://ajax.test.com/b.html" style="display:none;" name="b" height=0 width=0></iframe>
<br/>
<h1>同主域不同子域之间跨域测试</h1>
<span id="sp">以on委托事件代替普通点击</span>
<p id="son"></p>
<script>
    document.domain = "test.com";
	var name = "father";
	
	$("#sp").css({"cursor":"pointer","color":"red"});
	$("body").on("click","#sp",function(){
	    //父页面调取子页面变量
	    var son_b = window.frames["b"].b;
		var son_a = window.frames["b"].a;
		$("#son").html(son_a+" + "+son_b);
	})
</script>
</body>
</html>