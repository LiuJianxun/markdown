<?php
header("Content-Type:text/html;charset=utf-8");
define('DIR_ROOT', dirname(__FILE__));
require_once('../config/db.php');

$title = "jsonp实现原理1";
//模拟数据
$table = 'video_updown';
$news_id = '1';
$sql = "select up,down from {$table} where id = '{$news_id}'";
$result = select_one($conn,$sql);

require 'jsonp.html';
