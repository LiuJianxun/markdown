<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script type="text/javascript" src="../../jquery-1.8.3.js"></script>
<title>隐藏iframe实现局部刷新2</title>
</head>
<body>
<h1>同主域不同子域之间跨域测试2</h1>
<script type="text/javascript">
document.domain = "test.com";
function likeit(type)
{
    $("#displayVote").html("<b>Thank you for your vote!</b>");
    $("#ifAjax").attr("src","http://ajax.test.com/hiddenPage.php?type="+type+"&r=" + Math.random());
}

//回调函数
function callback(num,sum,type){
	$("#good_qty").html(num);
	$("#sum").html(sum);
	$("#like_type").html(type);
}
</script>

<body>

<form id="form1" runat="server">

<iframe id="ifAjax" name="ifAjax" style="display:none" src="about:blank"></iframe>

    <div id="displayVote" style="height:60px;">

	    <div class="sz_btn_style4" style="float:left;margin-right:30px;">

          <a href="javascript:;" onClick='likeit("like")'>

          <span>I like it!</span></a>
		</div>
        
		<div class="sz_btn_style4" style="float:left;">

          <a href="javascript:;" onClick='likeit("unlike")'>

          <span>Don't like it!</span></a>

        </div>

	</div>                                                        

    <div style="clear:both; padding-top:4px;">

          <label id="good_qty">47</label>/

          <label id="sum" >98</label>

           &nbsp;You <span id="like_type">like</span> this post&nbsp;

          <label id="bad_qty" style="display:none;">60</label>                     

    </div>  

</form>
</body>
</html>