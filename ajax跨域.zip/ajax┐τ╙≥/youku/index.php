<?php
/**
 * author : liujianxun
 * 本程序示例，实现类似优酷视频的顶踩功能，利用cookie实现[子域共享]
 * 展示程序在本地的/www/youku/目录，指定测试域名是：http://local.test.com
 * 顶踩动作功能放在/www/ajaxdo/目录下：指定域名是：http://ajax.test.com
 */
define('DIR_ROOT', dirname(__FILE__));
require_once('config/db.php');

//模拟数据
$table = 'video_updown';
$news_id = '1';
$sql = "select up,down from {$table} where id = '{$news_id}'";
$row = select_one($conn,$sql);

//判断操作cookie是否存在并判断其动作
$actionCookie = $_COOKIE['up_down_video'];
$actionType = '';
if(isset($actionCookie)&&(strrpos($actionCookie,"up")!==FALSE)){
    $actionType = 'up';  
}elseif(isset($actionCookie)&&(strrpos($actionCookie,"down")!==FALSE)){
    $actionType = 'down';
}

require 'view/updown.html';
