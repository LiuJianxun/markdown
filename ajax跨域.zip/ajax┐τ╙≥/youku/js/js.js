$(function(){
	$("#fn_up a").click(function(){
		//准备数据
		var newsId = $.trim($("#fn_updown").attr('newsId'));		
		var type = 'up';
		var addStep = 1;
		doUpDown(newsId,type,addStep);
	})

	$("#fn_down a").click(function(){
		//准备数据
		var newsId = $.trim($("#fn_updown").attr('newsId'));
		var type = 'down';		
		var addStep = 1;
		doUpDown(newsId,type,addStep);		
	})
	
})  

function doUpDown(newsId,type,addStep){
	//ajax 跨域请求!
    var Url = 'http://ajax.test.com/loadUpDown.php?newsId='+newsId+'&type='+type+'&addStep='+addStep;     
	$.getJSON(Url+"&format=json&callback=?",
		function(data){
			if(data.res==1){
				//更新DOM顶踩状态
				var upData = parseInt($("#upVideoTimes").html());
				var downData = parseInt($("#downVideoTimes").html());
				var actionHtml = '';
				if(data.action=='up'){
					actionHtml = '<em class="ico_up">▲</em>&nbsp;<em class="stat">已顶'+(upData+1)+'</em>';
					actionHtml += '&nbsp;<em class="stat">踩'+downData+'</em>';
				}else if(data.action=='down'){
					actionHtml = '<em class="stat">顶'+upData+'</em>';
					actionHtml += '&nbsp;<em class="stat">已踩'+(downData+1)+'</em>&nbsp;<em class="ico_down">▼</em>';
				}				
				var html = '<span class="return">'+actionHtml+'</span>';				
				$("#fn_updown").addClass('fn_return');
				$("#fn_updown").attr('disabled','true');
				$("#fn_updown").removeAttr('newsId');
				$("#fn_updown").html(html);				
			}else{
				alert(data.msg);return false;
			}
	    });
}